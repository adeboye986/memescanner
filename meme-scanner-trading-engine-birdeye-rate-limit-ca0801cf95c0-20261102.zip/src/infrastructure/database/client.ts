import { Kysely, PostgresDialect, sql, type ColumnType, type Generated } from 'kysely';
import { Pool, types, type PoolClient, type PoolConfig } from 'pg';

import type { DatabaseConfig } from '../../config/env.js';
import type { EventEnvelope } from '../../contracts/events/event-envelope.schema.js';
import type { EvaluationOutcome } from '../../domain/opportunities/evaluation-policy.js';
import { canonicalizeDatabaseDecimal } from '../../shared/amount/canonical-decimal.js';

types.setTypeParser(types.builtins.NUMERIC, canonicalizeDatabaseDecimal);

export type JsonValue =
  | null
  | boolean
  | number
  | string
  | readonly JsonValue[]
  | { readonly [key: string]: JsonValue };

export interface CommandInboxTable {
  id: string;
  idempotency_key: string;
  auth_jti: string;
  subject: string;
  command_name: string;
  request_hash: string;
  status: 'processing' | 'succeeded';
  response: JsonValue | null;
  correlation_id: string;
  traceparent: string;
  created_at: ColumnType<Date, Date | string | undefined, never>;
  completed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
}

export interface EventOutboxTable {
  id: string;
  event_type: string;
  aggregate_type: string;
  aggregate_id: string;
  aggregate_version: number;
  envelope: EventEnvelope;
  payload_sha256: string;
  correlation_id: string;
  traceparent: string;
  status: 'pending' | 'processing' | 'published';
  available_at: ColumnType<Date, Date | string | undefined, Date | string>;
  claimed_by: string | null;
  claimed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  attempt_count: Generated<number>;
  published_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface EventDeliveryAttemptTable {
  id: Generated<number>;
  event_id: string;
  attempt_number: number;
  outcome: 'published' | 'failed';
  response_status: number | null;
  error_code: string | null;
  next_attempt_at: ColumnType<Date | null, Date | string | null | undefined, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface OpportunityTable {
  id: string;
  aggregate_version: 1;
  state: 'recorded';
  source_system: string;
  source_opportunity_id: string;
  control_plane_user_id: string;
  discovery_key: string;
  scanner: 'new-token' | 'momentum';
  network_id: string;
  asset_address: string;
  symbol: string | null;
  name: string | null;
  price_usd: string | null;
  price_provider: string | null;
  market_cap_usd: string | null;
  market_cap_provider: string | null;
  liquidity_usd: string | null;
  liquidity_provider: string | null;
  volume_usd: string | null;
  volume_provider: string | null;
  volume_window: '1m' | '5m' | null;
  pair_address: string | null;
  dex: string | null;
  pair_provider: string | null;
  qualified_at: Date;
  discovery_market_cap_usd: string | null;
  move_since_discovery_percent: string | null;
  classification: string | null;
  security: JsonValue | null;
  accepted_request: JsonValue;
  request_sha256: string;
  received_at: ColumnType<Date, Date | string | undefined, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface EvaluationPolicyTable {
  policy_key: string;
  policy_version: number;
  algorithm_key: string;
  algorithm_version: number;
  definition: JsonValue;
  definition_sha256: string;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface OpportunityEvaluationTaskTable {
  opportunity_id: string;
  policy_key: string;
  policy_version: number;
  source_event_id: string;
  status: 'pending' | 'processing' | 'completed';
  available_at: ColumnType<Date, Date | string | undefined, Date | string>;
  claimed_by: string | null;
  claimed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  attempt_count: Generated<number>;
  last_error_code: string | null;
  completed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface OpportunityEvaluationTable {
  id: string;
  opportunity_id: string;
  policy_key: string;
  policy_version: number;
  policy_snapshot: JsonValue;
  policy_definition_sha256: string;
  source_request_sha256: string;
  evaluation_input_sha256: string;
  outcome: EvaluationOutcome;
  reason_codes: JsonValue;
  advisory_codes: JsonValue;
  evidence: JsonValue;
  result_sha256: string;
  correlation_id: string;
  traceparent: string;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperPositionLifecycleTable {
  id: string;
  source_position_id: string;
  source_opportunity_id: string;
  opportunity_id: string;
  control_plane_user_id: string;
  network_id: string;
  asset_address: string;
  symbol: string | null;
  initial_investment_native: string;
  entry_market_cap_usd: string;
  entry_price_usd: string | null;
  entry_liquidity_usd: string | null;
  strategy_snapshot: JsonValue;
  strategy_sha256: string;
  policy_key: string;
  policy_version: number;
  lifecycle_version: number;
  last_observation_id: string | null;
  last_observation_sequence: number;
  last_market_cap_usd: string | null;
  last_price_usd: string | null;
  last_liquidity_usd: string | null;
  peak_market_cap_usd: string;
  peak_multiple: string;
  max_drawdown_percent: string;
  protection_state: 'none' | 'level_1' | 'level_2';
  state: 'open' | 'terminal';
  registered_at: ColumnType<Date, Date | string, never>;
  last_observed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  terminal_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
  updated_at: ColumnType<Date, Date | string | undefined, Date | string>;
}

export interface PaperPositionLifecycleDecisionTable {
  id: string;
  position_id: string;
  observation_id: string;
  observation_sequence: number;
  lifecycle_version: number;
  request_sha256: string;
  result_sha256: string;
  evaluated_event_id: string;
  exit_event_id: string | null;
  decision: 'HOLD' | 'EXIT';
  exit_type: 'stop_loss' | 'protected_floor_exit' | null;
  observed_market_cap_usd: string;
  observed_price_usd: string | null;
  observed_liquidity_usd: string | null;
  observed_multiple: string;
  trigger_multiple: string | null;
  peak_market_cap_usd: string;
  peak_multiple: string;
  drawdown_percent: string;
  protection_before: 'none' | 'level_1' | 'level_2';
  protection_after: 'none' | 'level_1' | 'level_2';
  transitions: JsonValue;
  evidence: JsonValue;
  correlation_id: string;
  traceparent: string;
  observed_at: ColumnType<Date, Date | string, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperWalletTable {
  id: string;
  control_plane_user_id: string;
  network_id: string;
  currency: 'SOL';
  opening_balance_native: string;
  opening_reference: string;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperLedgerTransactionTable {
  id: string;
  wallet_id: string;
  transaction_type: 'opening_balance' | 'entry' | 'exit_settlement';
  reference_id: string;
  idempotency_key: string;
  correlation_id: string;
  occurred_at: ColumnType<Date, Date | string, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperLedgerEntryTable {
  id: string;
  transaction_id: string;
  wallet_id: string;
  account: 'available' | 'invested' | 'opening_equity' | 'realized_pnl';
  direction: 'debit' | 'credit';
  amount_native: string;
  currency: 'SOL';
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperEntryIntentTable {
  id: string;
  wallet_id: string;
  opportunity_id: string;
  evaluation_id: string;
  source_opportunity_id: string;
  control_plane_user_id: string;
  network_id: string;
  asset_address: string;
  status: 'executed';
  execution_mode: 'paper';
  entry_mode: 'auto';
  notional_native: string;
  intent_snapshot: JsonValue;
  intent_sha256: string;
  authority_snapshot: JsonValue;
  authority_sha256: string;
  idempotency_key: string;
  correlation_id: string;
  traceparent: string;
  accepted_at: ColumnType<Date, Date | string, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperOrderTable {
  id: string;
  intent_id: string;
  wallet_id: string;
  side: 'buy';
  order_type: 'simulated_market';
  status: 'filled';
  asset_address: string;
  requested_notional_native: string;
  currency: 'SOL';
  market_snapshot: JsonValue;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperFillTable {
  id: string;
  order_id: string;
  notional_native: string;
  fee_native: string;
  fill_price_usd: string;
  quantity: string;
  quantity_unit: 'normalized_position_unit';
  fill_model: 'observed_mark_normalized_notional_v1';
  executed_at: ColumnType<Date, Date | string, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperFinancialPositionTable {
  id: string;
  wallet_id: string;
  intent_id: string;
  order_id: string;
  fill_id: string;
  opportunity_id: string;
  evaluation_id: string;
  control_plane_user_id: string;
  network_id: string;
  asset_address: string;
  symbol: string | null;
  state: 'open' | 'closed';
  quantity: string;
  quantity_unit: 'normalized_position_unit';
  cost_basis_native: string;
  entry_price_usd: string;
  entry_market_cap_usd: string;
  entry_liquidity_usd: string | null;
  strategy_snapshot: JsonValue;
  strategy_sha256: string;
  authority_snapshot: JsonValue;
  authority_sha256: string;
  opened_at: ColumnType<Date, Date | string, never>;
  closed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  exit_price_usd: ColumnType<string | null, string | null | undefined, string | null>;
  exit_market_cap_usd: ColumnType<string | null, string | null | undefined, string | null>;
  exit_proceeds_native: ColumnType<string | null, string | null | undefined, string | null>;
  realized_pnl_native: ColumnType<string | null, string | null | undefined, string | null>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
  updated_at: ColumnType<Date, Date | string | undefined, Date | string>;
}

export interface PaperExitOrderTable {
  id: string;
  position_id: string;
  wallet_id: string;
  side: 'sell';
  order_type: 'simulated_market';
  status: 'filled';
  asset_address: string;
  quantity: string;
  currency: 'SOL';
  market_snapshot: JsonValue;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperExitFillTable {
  id: string;
  order_id: string;
  cost_basis_native: string;
  proceeds_native: string;
  realized_pnl_native: string;
  exit_price_usd: string;
  exit_market_cap_usd: string;
  observed_multiple: string;
  quantity: string;
  quantity_unit: 'normalized_position_unit';
  fill_model: 'observed_market_cap_ratio_v1';
  executed_at: ColumnType<Date, Date | string, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperExitSettlementTable {
  id: string;
  position_id: string;
  decision_id: string;
  order_id: string;
  fill_id: string;
  ledger_transaction_id: string;
  event_id: string;
  cost_basis_native: string;
  proceeds_native: string;
  realized_pnl_native: string;
  result_sha256: string;
  correlation_id: string;
  traceparent: string;
  settled_at: ColumnType<Date, Date | string, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface PaperPositionMonitoringTaskTable {
  position_id: string;
  network_id: string;
  asset_address: string;
  monitoring_state: 'pending' | 'processing' | 'completed';
  next_observation_due_at: ColumnType<Date, Date | string, Date | string>;
  lease_owner: string | null;
  lease_expires_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  last_successful_observation_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  last_fetch_attempted_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  consecutive_failure_count: Generated<number>;
  next_attempt_sequence: Generated<number>;
  observation_authority: Generated<'shadow' | 'financial'>;
  next_financial_observation_sequence: Generated<number>;
  provider_backoff_until: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  last_error_code: string | null;
  last_http_status: number | null;
  last_provider: string | null;
  last_market_cap_usd: string | null;
  last_price_usd: string | null;
  last_liquidity_usd: string | null;
  last_fetched_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  last_provider_observed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
  updated_at: ColumnType<Date, Date | string | undefined, Date | string>;
}

export interface PaperMarketShadowObservationTable {
  id: string;
  position_id: string;
  attempt_sequence: number;
  request_id: string;
  scheduled_due_at: ColumnType<Date, Date | string, never>;
  network_id: string;
  asset_address: string;
  outcome: 'discarded_closed' | 'failed' | 'observed' | 'unavailable';
  provider: 'dexscreener';
  pair_address: string | null;
  dex: string | null;
  market_cap_usd: string | null;
  price_usd: string | null;
  liquidity_usd: string | null;
  request_started_at: ColumnType<Date, Date | string, never>;
  response_received_at: ColumnType<Date, Date | string, never>;
  provider_latency_ms: number;
  provider_observed_at: ColumnType<Date | null, Date | string | null, never>;
  fetched_at: ColumnType<Date | null, Date | string | null, never>;
  error_code: string | null;
  http_status: number | null;
  retry_after_ms: number | null;
  consecutive_failure_count: number;
  next_observation_due_at: ColumnType<Date | null, Date | string | null, never>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
}

export interface TokenScanExecutionTable {
  id: string;
  source_system: 'meme-scanner-laravel';
  source_activity_id: string;
  control_plane_user_id: string;
  scanner: 'new-token' | 'momentum';
  network_id: string;
  state: 'pending' | 'processing' | 'succeeded' | 'succeeded_with_warnings' | 'failed';
  attempt_count: Generated<number>;
  next_attempt_at: ColumnType<Date, Date | string | undefined, Date | string>;
  lease_owner: string | null;
  lease_expires_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  request: JsonValue;
  request_sha256: string;
  idempotency_key: string;
  correlation_id: string;
  traceparent: string;
  discovered_count: Generated<number>;
  examined_count: Generated<number>;
  qualified_count: Generated<number>;
  opportunities_created_count: Generated<number>;
  opportunities_existing_count: Generated<number>;
  skipped_count: Generated<number>;
  failed_count: Generated<number>;
  provider_failures: JsonValue;
  last_error_code: string | null;
  started_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  completed_at: ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
  created_at: ColumnType<Date, Date | string | undefined, never>;
  updated_at: ColumnType<Date, Date | string | undefined, Date | string>;
}

export interface TokenDiscoveryTable {
  id: string;
  scan_execution_id: string;
  network_id: string;
  asset_address: string;
  symbol: string | null;
  name: string | null;
  provider: 'birdeye' | 'dexscreener' | 'geckoterminal';
  discovery_index: number;
  state: 'discovered' | 'skipped' | 'qualified' | 'qualified_downstream_failed' | 'opportunity_created' | 'opportunity_existing' | 'failed';
  reason_code: string | null;
  market_snapshot: JsonValue | null;
  security_snapshot: JsonValue | null;
  qualification_snapshot: JsonValue | null;
  opportunity_id: string | null;
  created_at: ColumnType<Date, Date | string | undefined, never>;
  updated_at: ColumnType<Date, Date | string | undefined, Date | string>;
}

export interface Database {
  command_inbox: CommandInboxTable;
  event_outbox: EventOutboxTable;
  event_delivery_attempts: EventDeliveryAttemptTable;
  opportunities: OpportunityTable;
  evaluation_policies: EvaluationPolicyTable;
  opportunity_evaluation_tasks: OpportunityEvaluationTaskTable;
  opportunity_evaluations: OpportunityEvaluationTable;
  paper_wallets: PaperWalletTable;
  paper_ledger_transactions: PaperLedgerTransactionTable;
  paper_ledger_entries: PaperLedgerEntryTable;
  paper_entry_intents: PaperEntryIntentTable;
  paper_orders: PaperOrderTable;
  paper_fills: PaperFillTable;
  paper_positions: PaperFinancialPositionTable;
  paper_position_lifecycles: PaperPositionLifecycleTable;
  paper_position_lifecycle_decisions: PaperPositionLifecycleDecisionTable;
  paper_exit_orders: PaperExitOrderTable;
  paper_exit_fills: PaperExitFillTable;
  paper_exit_settlements: PaperExitSettlementTable;
  paper_position_monitoring_tasks: PaperPositionMonitoringTaskTable;
  paper_market_shadow_observations: PaperMarketShadowObservationTable;
  token_scan_executions: TokenScanExecutionTable;
  token_discoveries: TokenDiscoveryTable;
}

export interface DatabaseConnectionLossSignal {
  readonly lost: Promise<void>;
  isLost(): boolean;
}

class MutableDatabaseConnectionLossSignal implements DatabaseConnectionLossSignal {
  public readonly lost: Promise<void>;
  private lostState = false;
  private resolveLost: () => void = (): void => undefined;

  public constructor() {
    this.lost = new Promise((resolve) => {
      this.resolveLost = resolve;
    });
  }

  public isLost(): boolean {
    return this.lostState;
  }

  public markLost(): void {
    if (this.lostState) {
      return;
    }

    this.lostState = true;
    this.resolveLost();
  }
}

interface TrackedConnection {
  backendPid: number | null;
  readonly signal: MutableDatabaseConnectionLossSignal;
  readonly onEnd: () => void;
  readonly onError: () => void;
}

export class DatabaseConnectionLossMonitor {
  private readonly connections = new WeakMap<PoolClient, TrackedConnection>();
  private readonly connectionsByBackendPid = new Map<number, TrackedConnection>();
  private attached = false;

  public attach(pool: Pool): void {
    if (this.attached) {
      throw new Error('PostgreSQL connection loss monitor is already attached');
    }

    this.attached = true;
    pool.on('connect', this.onConnect);
    pool.on('error', this.onPoolError);
    pool.on('remove', this.onRemove);
  }

  public readonly verify = (
    client: PoolClient,
    done: (error?: Error) => void,
  ): void => {
    void this.initialize(client).then(
      () => {
        done();
      },
      (error: unknown) => {
        done(error instanceof Error
          ? error
          : new Error(
              'PostgreSQL connection monitoring initialization failed',
              { cause: error },
            ));
      },
    );
  };

  public signalForBackendPid(backendPid: number): DatabaseConnectionLossSignal | undefined {
    return this.connectionsByBackendPid.get(backendPid)?.signal;
  }

  private readonly onConnect = (client: PoolClient): void => {
    if (this.connections.has(client)) {
      return;
    }

    const signal = new MutableDatabaseConnectionLossSignal();
    const onError = (): void => {
      signal.markLost();
    };
    const onEnd = (): void => {
      signal.markLost();
    };
    const connection = { backendPid: null, signal, onEnd, onError };

    this.connections.set(client, connection);
    client.on('error', onError);
    client.on('end', onEnd);
  };

  private async initialize(client: PoolClient): Promise<void> {
    const connection = this.connections.get(client);

    if (connection === undefined) {
      throw new Error('PostgreSQL connection monitoring was not registered');
    }

    const result = await client.query<{ readonly pid: number }>(
      'select pg_backend_pid()::int as pid',
    );
    const backendPid = result.rows[0]?.pid;

    if (backendPid === undefined || !Number.isSafeInteger(backendPid) || backendPid <= 0) {
      throw new Error('PostgreSQL connection monitoring returned an invalid backend PID');
    }

    if (this.connections.get(client) !== connection || connection.signal.isLost()) {
      throw new Error('PostgreSQL connection was lost during monitoring initialization');
    }

    if (
      connection.backendPid !== null
      && connection.backendPid !== backendPid
      && this.connectionsByBackendPid.get(connection.backendPid) === connection
    ) {
      this.connectionsByBackendPid.delete(connection.backendPid);
    }

    connection.backendPid = backendPid;
    this.connectionsByBackendPid.set(backendPid, connection);
  }

  private readonly onPoolError = (_error: Error, client: PoolClient): void => {
    this.connections.get(client)?.signal.markLost();
  };

  private readonly onRemove = (client: PoolClient): void => {
    const connection = this.connections.get(client);

    if (connection === undefined) {
      return;
    }

    connection.signal.markLost();
    client.removeListener('error', connection.onError);
    client.removeListener('end', connection.onEnd);
    this.connections.delete(client);

    if (
      connection.backendPid !== null
      && this.connectionsByBackendPid.get(connection.backendPid) === connection
    ) {
      this.connectionsByBackendPid.delete(connection.backendPid);
    }
  };
}

const connectionLossMonitors = new WeakMap<
  Kysely<Database>,
  DatabaseConnectionLossMonitor
>();

export function createDatabasePoolConfig(config: DatabaseConfig): PoolConfig {
  const ssl = config.databaseSsl
    ? {
        rejectUnauthorized: true,
        ...(config.databaseCaCertificate === undefined
          ? {}
          : { ca: config.databaseCaCertificate }),
      }
    : undefined;

  return {
    connectionString: config.databaseUrl,
    max: config.databaseMaxConnections,
    ssl,
    application_name: config.serviceName ?? 'meme-scanner-trading-engine-migrate',
  };
}

export function createDatabase(config: DatabaseConfig): Kysely<Database> {
  const connectionLossMonitor = new DatabaseConnectionLossMonitor();
  const pool = new Pool({
    ...createDatabasePoolConfig(config),
    verify: connectionLossMonitor.verify,
  });
  connectionLossMonitor.attach(pool);
  const database = new Kysely<Database>({
    dialect: new PostgresDialect({
      pool,
    }),
  });

  connectionLossMonitors.set(database, connectionLossMonitor);

  return database;
}

export function databaseConnectionLossSignal(
  database: Kysely<Database>,
  backendPid: number,
): DatabaseConnectionLossSignal | undefined {
  return connectionLossMonitors.get(database)?.signalForBackendPid(backendPid);
}

export async function pingDatabase(database: Kysely<Database>): Promise<void> {
  await sql<{ readonly healthy: number }>`select 1 as healthy`.execute(database);
}
